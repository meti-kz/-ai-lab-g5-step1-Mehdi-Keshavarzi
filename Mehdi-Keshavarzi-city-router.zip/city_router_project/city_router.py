"""City router project adapted from the class vacuum-agent exercise.

The original one-dimensional, four-room environment is replaced with a two-
dimensional grid. A cell is either open (0) or blocked (1). BFS finds a
shortest path when all moves have the same cost.
"""

from collections import deque
from time import perf_counter
from typing import Iterable, Optional, Sequence

import numpy as np

Coordinate = tuple[int, int]
Grid = np.ndarray

# Four actions correspond to moving one cell: up, right, down, left.
MOVES: tuple[tuple[int, int], ...] = ((-1, 0), (0, 1), (1, 0), (0, -1))


def validate_grid(grid: Grid) -> Grid:
    """Return grid as a 2-D NumPy array and validate its cell values."""
    array = np.asarray(grid)
    if array.ndim != 2 or array.size == 0:
        raise ValueError("grid must be a non-empty 2-D array")
    if not np.isin(array, [0, 1]).all():
        raise ValueError("grid cells must be 0 (open) or 1 (blocked)")
    return array.astype(np.int8, copy=False)


def validate_coordinate(coord: Sequence[int], grid: Grid, name: str) -> Coordinate:
    """Validate and normalize a (row, column) coordinate."""
    if len(coord) != 2:
        raise ValueError(f"{name} must contain row and column")
    row, col = coord
    if not isinstance(row, (int, np.integer)) or not isinstance(col, (int, np.integer)):
        raise ValueError(f"{name} row and column must be integers")
    if not (0 <= row < grid.shape[0] and 0 <= col < grid.shape[1]):
        raise ValueError(f"{name} {tuple(coord)} is outside the grid")
    if grid[row, col] == 1:
        raise ValueError(f"{name} {tuple(coord)} is blocked")
    return int(row), int(col)


def bfs_path(
    grid: Grid,
    start: Sequence[int],
    goal: Sequence[int],
) -> tuple[Optional[list[Coordinate]], list[Coordinate]]:
    """Find a shortest path using BFS.

    Returns (path, explored_cells). The path includes both start and goal;
    path is None when no route exists. Coordinates use zero-based (row, col).
    """
    grid = validate_grid(grid)
    start = validate_coordinate(start, grid, "start")
    goal = validate_coordinate(goal, grid, "goal")

    queue = deque([start])
    parent: dict[Coordinate, Optional[Coordinate]] = {start: None}
    explored: list[Coordinate] = []

    while queue:
        current = queue.popleft()
        explored.append(current)
        if current == goal:
            break

        for dr, dc in MOVES:
            neighbor = (current[0] + dr, current[1] + dc)
            row, col = neighbor
            if not (0 <= row < grid.shape[0] and 0 <= col < grid.shape[1]):
                continue
            if grid[row, col] == 1 or neighbor in parent:
                continue
            parent[neighbor] = current
            queue.append(neighbor)

    if goal not in parent:
        return None, explored

    path: list[Coordinate] = []
    current: Optional[Coordinate] = goal
    while current is not None:
        path.append(current)
        current = parent[current]
    path.reverse()
    return path, explored


def make_city_map() -> tuple[Grid, Coordinate, Coordinate]:
    """Create a deterministic example city grid with roads and roadblocks."""
    grid = np.zeros((9, 12), dtype=np.int8)

    # Vertical and horizontal blocked roads. Deliberate gaps keep the map connected.
    grid[1:6, 3] = 1
    grid[3, 3] = 0

    grid[1, 5:9] = 1
    grid[1, 7] = 0

    grid[3:8, 6] = 1
    grid[6, 6] = 0

    grid[1:5, 9] = 1
    grid[2, 9] = 0

    grid[6, 1:5] = 1
    grid[6, 2] = 0

    grid[7, 7:11] = 1

    start: Coordinate = (0, 0)
    goal: Coordinate = (8, 11)
    return grid, start, goal


def plot_route(
    grid: Grid,
    start: Coordinate,
    goal: Coordinate,
    path: Optional[Iterable[Coordinate]],
    explored: Optional[Iterable[Coordinate]] = None,
    title: str = "City Router: BFS shortest path",
) -> None:
    """Visualize open cells, blocked cells, explored cells, and final route."""
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    grid = validate_grid(grid)
    # Base colors: open is near-white, blocked is dark grey.
    image = np.where(grid == 1, 0.22, 1.0)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.imshow(image, cmap="gray", vmin=0, vmax=1, origin="upper")

    if explored is not None:
        for row, col in explored:
            if (row, col) not in (start, goal) and grid[row, col] == 0:
                ax.scatter(col, row, s=55, marker="s", color="#b9d8f5", zorder=2)

    if path:
        route = list(path)
        xs = [col for row, col in route]
        ys = [row for row, col in route]
        ax.plot(xs, ys, color="#e4572e", linewidth=3, marker="o", markersize=4, zorder=3)

    ax.scatter(start[1], start[0], s=180, marker="o", color="#24a148", edgecolor="black", zorder=4)
    ax.scatter(goal[1], goal[0], s=180, marker="*", color="#ffd43b", edgecolor="black", zorder=4)
    ax.text(start[1], start[0] - 0.25, "S", ha="center", va="bottom", weight="bold")
    ax.text(goal[1], goal[0] - 0.25, "G", ha="center", va="bottom", weight="bold")

    ax.set_xticks(range(grid.shape[1]))
    ax.set_yticks(range(grid.shape[0]))
    ax.set_xticks(np.arange(-0.5, grid.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, grid.shape[0], 1), minor=True)
    ax.grid(which="minor", color="#c8c8c8", linewidth=0.8)
    ax.tick_params(which="minor", bottom=False, left=False)
    ax.set_xlabel("Column (zero-based)")
    ax.set_ylabel("Row (zero-based)")
    ax.set_title(title)
    legend_items = [
        Patch(facecolor="#ffffff", edgecolor="#aaaaaa", label="Open road"),
        Patch(facecolor="#383838", label="Blocked road"),
        Patch(facecolor="#b9d8f5", label="Explored cell"),
        Line2D([0], [0], color="#e4572e", marker="o", label="Found route"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor="#24a148", markeredgecolor="black", label="Start"),
        Line2D([0], [0], marker="*", color="w", markerfacecolor="#ffd43b", markeredgecolor="black", label="Goal"),
    ]
    ax.legend(handles=legend_items, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=3, frameon=False)
    fig.tight_layout()
    plt.show()


def evaluate_examples() -> list[dict[str, object]]:
    """Run small tests and return a table-ready list of results."""
    cases = [
        ("open grid", np.zeros((3, 3), dtype=int), (0, 0), (2, 2), True),
        ("detour", np.array([[0, 1, 0], [0, 1, 0], [0, 0, 0]]), (0, 0), (0, 2), True),
        ("no route", np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]]), (0, 0), (2, 2), False),
        ("start equals goal", np.zeros((2, 2), dtype=int), (1, 1), (1, 1), True),
    ]
    results: list[dict[str, object]] = []
    for name, grid, start, goal, expected_success in cases:
        began = perf_counter()
        path, explored = bfs_path(grid, start, goal)
        elapsed_ms = (perf_counter() - began) * 1000
        success = path is not None
        results.append({
            "test": name,
            "expected_success": expected_success,
            "success": success,
            "test_passed": success == expected_success,
            "path_moves": len(path) - 1 if path else None,
            "explored_cells": len(explored),
            "runtime_ms": round(elapsed_ms, 4),
        })
    return results


def evaluate_random_maps(
    runs: int = 100,
    rows: int = 12,
    cols: int = 15,
    obstacle_probability: float = 0.22,
    seed: int = 42,
) -> dict[str, float | int]:
    """Benchmark BFS on reproducible randomly generated maps."""
    if runs < 1 or rows < 2 or cols < 2:
        raise ValueError("runs must be >= 1 and rows/cols must be >= 2")
    if not 0 <= obstacle_probability < 1:
        raise ValueError("obstacle_probability must be in [0, 1)")

    rng = np.random.default_rng(seed)
    start: Coordinate = (0, 0)
    goal: Coordinate = (rows - 1, cols - 1)
    success_count = 0
    path_lengths: list[int] = []
    runtimes_ms: list[float] = []

    for _ in range(runs):
        grid = (rng.random((rows, cols)) < obstacle_probability).astype(np.int8)
        grid[start] = 0
        grid[goal] = 0
        began = perf_counter()
        path, _ = bfs_path(grid, start, goal)
        runtimes_ms.append((perf_counter() - began) * 1000)
        if path is not None:
            success_count += 1
            path_lengths.append(len(path) - 1)

    return {
        "runs": runs,
        "successes": success_count,
        "success_rate_percent": round(100 * success_count / runs, 2),
        "mean_path_moves_when_successful": round(float(np.mean(path_lengths)), 2) if path_lengths else float("nan"),
        "mean_runtime_ms": round(float(np.mean(runtimes_ms)), 4),
        "grid_rows": rows,
        "grid_columns": cols,
        "obstacle_probability": obstacle_probability,
        "random_seed": seed,
    }


if __name__ == "__main__":
    city, source, destination = make_city_map()
    route, visited = bfs_path(city, source, destination)
    if route is None:
        print("No route exists between start and goal.")
    else:
        print(f"Route found: {len(route) - 1} moves")
        print("Coordinates:", route)
    plot_route(city, source, destination, route, visited)
